# Dependencies

Refer to [DEPENDENCIES.rust.tsv](DEPENDENCIES.rust.tsv) for full list.
