# Cargo Contributor Guide

This is the source of the Cargo Contributor Guide, published at
<https://rust-lang.github.io/cargo/contrib/>. It is written in Markdown, using
the [mdbook] tool to convert to HTML. If you are editing these pages, the best
option to view the results is to run `mdbook serve`, which will start a web
server on localhost that you can visit to view the book, and it will
automatically reload each time you edit a page.

This is published via GitHub Actions to GitHub Pages.

[mdbook]: https://rust-lang.github.io/mdBook/
