{{#option "`--manifest-path` _path_" }}
Path to the `Cargo.toml` file. By default, Cargo searches for the
`Cargo.toml` file in the current directory or any parent directory.
{{/option}}
