#include <stdio.h>

void foo() {
  printf("hello world\n");
}
