// Env values used in oracle cloud infrastructure services.
pub const ORACLE_CONFIG_PATH: &str = "~/.oci/config";
