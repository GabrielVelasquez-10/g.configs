# retry

[![Build Status](https://travis-ci.org/jimmycuadra/retry.svg?branch=master)](https://travis-ci.org/jimmycuadra/retry)

Crate `retry` provides utilities for retrying operations that can fail.

## Documentation

retry has [comprehensive documentation](https://docs.rs/retry) available on docs.rs.

## Legal

retry is released under the MIT license.
See `LICENSE`.
