---
name: Bug Report
about: For reporting an encountered issue
title: "[bug] Manufacturer Model"
labels: bug
assignees: ''

---
